export interface Post {
    id: number;
    titulo: string;
    descripcion: string;
    destinatario: string;
    firmantes: number;
    estado: string;
    user_id: number;
    categoria_id: number;
    file:string;
    files:any;
    }