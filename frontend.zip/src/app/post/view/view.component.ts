import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../post';
    
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
     
  id!: number;
  post!: Post;
  image:string="";
  categoria_id:number=0;
    
  /*------------------------------------------
  --------------------------------------------
  Created constructor
  --------------------------------------------
  --------------------------------------------*/
  constructor(
    public postService: PostService,
    private route: ActivatedRoute,
    private router: Router
   ) { }
    
  /**
   * Write code on Method
   *
   * @return response()
   */
  ngOnInit(): void {
    this.id = this.route.snapshot.params['postId'];
        
    this.postService.find(this.id).subscribe((data: any)=>{
      this.post = data;
      // this.categoria_id = this.post.categoria_id.nombre;
      // this.image = this.serverURL+this.peticion.files[0].file_path;
    });
  }

  firmarPeticion(id: number) {
    this.postService.firmar(this.id).subscribe((data:any)=>{
      this.post = data;
      // this.categoria_id = this.post.categoria_id.nombre;
    })
    this.router.navigate(['/peticiones/firmar', id]);
  }
    
}